# Lab 3: Wall Following

## YouTube video links
Simulator (individual) : [https://youtu.be/mzHUuMvEFhg](https://youtu.be/mzHUuMvEFhg)

Hardware (group) : [https://youtu.be/TSYti8dvpAM?si=8wltwXPeQsOM4z7f](https://youtu.be/TSYti8dvpAM?si=8wltwXPeQsOM4z7f)
