# Lab 6: SLAM and Pure Pursuit

## YouTube video link
[Simulation](https://youtu.be/43tPl5PxtZ4)

## Real car
Did not attempt
