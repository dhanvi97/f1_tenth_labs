# Lab 6: SLAM and Pure Pursuit

## YouTube video link
[Simulation](https://youtu.be/suDfm4eoZ5Y)
[AI Maker Space](https://youtu.be/-1OSw3Xrp74)
