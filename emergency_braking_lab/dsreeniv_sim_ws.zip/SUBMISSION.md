# Lab 2: Automatic Emergency Braking

## YouTube video link
[https://youtu.be/A2xyQImm0VM](https://youtu.be/A2xyQImm0VM)
