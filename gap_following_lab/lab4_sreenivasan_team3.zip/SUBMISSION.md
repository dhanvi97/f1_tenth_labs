# Lab 4: Follow the Gap

## YouTube video link
[Levine Blocked](https://youtu.be/5swrc8L4Xzk)
[Levine Obstacle](https://youtu.be/KajX-9nFUEk)
[Car Demo](https://youtu.be/SiyBKEsNUrs?si=XS6ppchK6u8c8RC4)
