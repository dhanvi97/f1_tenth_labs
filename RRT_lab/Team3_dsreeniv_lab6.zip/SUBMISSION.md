# Lab 1: Automatic Emergency Braking

## Video Link
Details of implementation are in the video description of the simulation video
(Simulation)[https://youtu.be/mGuT0LhMazw]
(AIMS Run)[https://youtu.be/5GoLqDLuUb0]
